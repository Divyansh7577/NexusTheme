{{-- NexusTheme injection partial --}}
{{-- Ye file sirf ek chhota snippet hai jo main master.blade.php ke <head> mein include hoga --}}

<link rel="stylesheet" href="{{ asset('themes/nexustheme/css/neon-blue.css') }}">

<style>
    /* Chhote inline tweaks jo direct yahan overwrite karne hain */
    .nexus-badge {
        display: inline-block;
        padding: 2px 8px;
        font-size: 11px;
        border-radius: 6px;
        background: rgba(0,229,255,0.15);
        color: #00e5ff;
        border: 1px solid #00b8d4;
    }
</style>
